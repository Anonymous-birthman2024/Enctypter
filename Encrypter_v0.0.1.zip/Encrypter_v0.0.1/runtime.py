from encrypt_module import encrypt
from decrypt_module import decrypt
import time
if __name__ == "__main__":
    while True:
        print("Are you encrypting or decrypting?")
        reply = input("[1]Encrypting [2]Decrypting [3]Quit App")
        if reply == "1":
            encrypt()
        elif reply == "2":
            decrypt()
        elif reply == "3":
            print("Quitting App...")
            time.sleep(1)
            print("Saving...")
            time.sleep(1)
            print("Disconnecting Dependencies...")
            time.sleep(1)
            print("Done.")
            break
        else:
            print("Invalid Selection. Try again.")
    print("Thank you for using Encrypter.")
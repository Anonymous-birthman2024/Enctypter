import time

def decrypt():
    print("Type in the numbers you received.")
    user = input("Type here, exactly as you received it: ")
    decryptListHelper = []
    decryptListHelper.append(user.split())
    for i in decryptListHelper:
        j = chr(i)
        print(j)
        time.sleep(2)
        
import time
def encrypt():
    code_storage = []
    user = input("Enter a message: ")
    print(f"Saved {str(len(user))}")
    print("Please record the following numbers on paper and mail it to your recipient. Separate the numbers with spaces")
    for i in user:
        j = ord(i)
        print(j)
        time.sleep(2)